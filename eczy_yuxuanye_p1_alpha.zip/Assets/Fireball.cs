﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fireball : MonoBehaviour {

	void OnCollisionEnter(){
		Destroy (gameObject);
	}
}
